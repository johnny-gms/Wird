# WIRD — version hébergée (PWA + notifications)

Contenu du dossier
- `index.html` : l'app (identique à la version Claude + lien vers le manifeste)
- `manifest.webmanifest`, `icons/` : nom WIRD, mode standalone, thème vert, icônes (192, 512, maskable, 180 pour iPhone)
- `sw.js` : service worker (hors connexion + réception des notifications)
- `server/` : serveur de notifications Web Push (Node 18+)

## 1. Héberger l'app (HTTPS obligatoire)
Mets `index.html`, `manifest.webmanifest`, `sw.js` et le dossier `icons/` à la racine d'un hébergement HTTPS statique (Netlify, Cloudflare Pages, GitHub Pages…). Garde ces fichiers au même niveau.

## 2. Installer sur iPhone (obligatoire pour les notifications)
Safari → Partager → « Sur l'écran d'accueil ». iOS 16.4 minimum. Les notifications ne marchent que depuis l'icône installée, pas dans un onglet Safari.

## 3. Déployer le serveur de notifications
1. Mets le contenu du dossier `server/` (package.json et server.js) dans un dépôt GitHub.
2. Sur Render (ou Railway / Fly.io) : nouveau Web Service Node depuis ce dépôt, build `npm install`, start `npm start`. Choisis une offre **toujours active** avec un **disque persistant** monté sur `/data` (les offres gratuites s'endorment et perdent leurs fichiers : les rappels ne partiraient pas).
3. Variables d'environnement : `ORIGIN` = URL exacte de l'app (ex. `https://xxxx.netlify.app`, sans `/` final) et `DATA_FILE` = `/data/data.json`. Les clés VAPID sont créées automatiquement au premier démarrage.
4. Vérifie : `https://URL-DU-SERVEUR/api/vapid` doit afficher `{"key":"..."}`.
5. Dans `index.html`, remplace `const PUSH={api:""}` par `const PUSH={api:"https://URL-DU-SERVEUR"}` et remets les fichiers en ligne.

## 4. Fonctionnement
- L'utilisateur active volontairement les rappels dans Profil, choisit heure et jours, peut mettre en pause ou désactiver.
- Le serveur envoie au maximum 1 notification par jour, à l'heure choisie : rappel de révision si des passages sont arrivés à échéance, ou invitation douce après au moins 3 jours d'absence.
- Si les notifications sont ignorées, elles s'espacent (3 jours, puis 7). Aucun message de culpabilisation, aucune série de jours.
- Données stockées côté serveur : adresse d'abonnement du navigateur, préférences de rappel, nombre de passages à réviser, date de dernière séance. Aucun contenu de mémorisation.

## Limites
- Stockage serveur en fichier JSON : suffisant pour un test, à remplacer par une base de données pour un usage large.
- Je n'ai pas pu tester l'envoi réel sur un iPhone : il faut déployer le serveur pour le vérifier.
