// WIRD — serveur de notifications Web Push (sans IA). Node 18+.
// Variables d'environnement : ORIGIN (URL exacte de l'app, sans "/" final) — obligatoire.
// Facultatives : DATA_FILE (chemin sur DISQUE PERSISTANT, ex. /data/data.json), PORT, BASE_URL, VAPID_SUBJECT, VAPID_PUBLIC + VAPID_PRIVATE.
// Si les clés VAPID ne sont pas fournies, elles sont créées au premier démarrage et conservées à côté de DATA_FILE.
const express = require("express"), webpush = require("web-push"), crypto = require("crypto"), fs = require("fs");
const FILE = process.env.DATA_FILE || "data.json";
const { ORIGIN } = process.env;
const BASE_URL = process.env.BASE_URL || process.env.RENDER_EXTERNAL_URL;
if (!ORIGIN || !BASE_URL) { console.error("ORIGIN (et BASE_URL si hors Render) manquants — voir README"); process.exit(1); }
let { VAPID_PUBLIC, VAPID_PRIVATE } = process.env;
if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
  try { ({ VAPID_PUBLIC, VAPID_PRIVATE } = JSON.parse(fs.readFileSync(FILE + ".vapid", "utf8"))); }
  catch (_) { const k = webpush.generateVAPIDKeys(); VAPID_PUBLIC = k.publicKey; VAPID_PRIVATE = k.privateKey; fs.writeFileSync(FILE + ".vapid", JSON.stringify({ VAPID_PUBLIC, VAPID_PRIVATE }), { mode: 0o600 }); }
}
webpush.setVapidDetails(process.env.VAPID_SUBJECT || ORIGIN, VAPID_PUBLIC, VAPID_PRIVATE);

let DB = {}; try { DB = JSON.parse(fs.readFileSync(FILE, "utf8")); } catch (_) {}
const persist = () => { fs.writeFileSync(FILE + ".tmp", JSON.stringify(DB)); fs.renameSync(FILE + ".tmp", FILE); };
const sha = s => crypto.createHash("sha256").update(String(s)).digest("hex");
const idOf = ep => sha(ep);

// --- sécurité de base : CORS restreint, corps limité, limitation de débit par IP ---
const app = express(); app.disable("x-powered-by"); app.set("trust proxy", 1);
app.use((req, res, next) => {
  res.set({ "Access-Control-Allow-Origin": ORIGIN, "Access-Control-Allow-Headers": "Content-Type, X-WIRD-Token", "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "X-Content-Type-Options": "nosniff" });
  if (req.method === "OPTIONS") return res.sendStatus(204); next();
});
const hits = new Map(); setInterval(() => hits.clear(), 60000);
app.use((req, res, next) => { const n = (hits.get(req.ip) || 0) + 1; hits.set(req.ip, n); n > 60 ? res.sendStatus(429) : next(); });
app.use(express.json({ limit: "20kb" }));

const clean = p => ({
  time: /^\d\d:\d\d$/.test(p && p.time) ? p.time : "19:00",
  days: Array.isArray(p && p.days) && p.days.length === 7 ? p.days.map(x => (x ? 1 : 0)) : [1, 1, 1, 1, 1, 1, 1],
  pause: /^\d{4}-\d\d-\d\d$/.test(p && p.pause) ? p.pause : "",
  resume: !!(p && p.resume),
  tz: (() => { try { new Intl.DateTimeFormat("fr", { timeZone: p.tz }); return p.tz; } catch (_) { return "Europe/Paris"; } })()
});
const auth = (req, rec) => { if (!rec) return false; const a = Buffer.from(sha(req.get("X-WIRD-Token") || "")), b = Buffer.from(rec.token); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const okEp = ep => typeof ep === "string" && ep.startsWith("https://") && ep.length < 1000;

app.get("/api/vapid", (_, res) => res.json({ key: VAPID_PUBLIC }));
app.post("/api/subscribe", (req, res) => {
  const { sub, prefs } = req.body || {};
  if (!sub || !okEp(sub.endpoint) || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) return res.sendStatus(400);
  const token = crypto.randomBytes(24).toString("hex");
  DB[idOf(sub.endpoint)] = { sub: { endpoint: sub.endpoint, keys: sub.keys }, prefs: clean(prefs), token: sha(token), due: 0, last: "", lastSent: "", ignored: 0, nonce: "" };
  persist(); res.json({ token });
});
app.post("/api/prefs", (req, res) => { const r = DB[idOf((req.body || {}).endpoint)]; if (!auth(req, r)) return res.sendStatus(401); r.prefs = clean(req.body.prefs); persist(); res.sendStatus(204); });
app.post("/api/state", (req, res) => {
  const r = DB[idOf((req.body || {}).endpoint)]; if (!auth(req, r)) return res.sendStatus(401);
  r.due = Math.max(0, Math.min(999, +req.body.due || 0)); r.last = /^\d{4}-\d\d-\d\d$/.test(req.body.last) ? req.body.last : "";
  if (req.body.prefs) r.prefs = clean(req.body.prefs); persist(); res.sendStatus(204);
});
app.post("/api/unsubscribe", (req, res) => { const id = idOf((req.body || {}).endpoint); if (!auth(req, DB[id])) return res.sendStatus(401); delete DB[id]; persist(); res.sendStatus(204); });
app.post("/api/ack/:nonce", (req, res) => { for (const r of Object.values(DB)) if (r.nonce && r.nonce === req.params.nonce) { r.nonce = ""; r.ignored = 0; persist(); break; } res.sendStatus(204); });

// --- planificateur : une vérification par minute ---
const dayDiff = (a, b) => Math.round((new Date(b + "T12:00Z") - new Date(a + "T12:00Z")) / 864e5);
function local(tz) {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false, weekday: "short" }).formatToParts(new Date()).map(x => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, min: (+p.hour % 24) * 60 + +p.minute, dow: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(p.weekday) };
}
async function tick() {
  for (const [id, r] of Object.entries(DB)) {
    const L = local(r.prefs.tz), [h, m] = r.prefs.time.split(":").map(Number), target = h * 60 + m;
    if (!r.prefs.days[L.dow] || L.min < target || L.min >= target + 120 || r.lastSent === L.date) continue;
    if (r.prefs.pause && L.date <= r.prefs.pause) continue;                       // en pause jusqu'à cette date incluse
    const gap = r.ignored >= 6 ? 7 : r.ignored >= 3 ? 3 : 1;                      // moins de rappels s'ils sont ignorés
    if (r.lastSent && dayDiff(r.lastSent, L.date) < gap) continue;
    let body = null;
    if (r.due > 0) body = r.due === 1 ? "Un passage est à réviser aujourd’hui. Quelques minutes suffisent." : `${Math.min(r.due, 9)} passages à réviser aujourd’hui. Quelques minutes suffisent.`;
    else if (r.prefs.resume && r.last && dayDiff(r.last, L.date) >= 3) body = "Une petite séance de 5 minutes pour reprendre à ton rythme ?";
    if (!body) continue;                                                           // au maximum 1 notification par jour, jamais de série ni de culpabilisation
    const nonce = crypto.randomBytes(12).toString("hex");
    try {
      await webpush.sendNotification(r.sub, JSON.stringify({ title: "WIRD", body, ack: `${BASE_URL}/api/ack/${nonce}` }), { TTL: 3600, urgency: "low" });
      if (r.nonce) r.ignored++; r.nonce = nonce; r.lastSent = L.date; persist();
    } catch (e) { if (e.statusCode === 404 || e.statusCode === 410) { delete DB[id]; persist(); } else console.error("push", e.statusCode || e.message); }
  }
}
setInterval(() => tick().catch(console.error), 60000);
app.listen(process.env.PORT || 3000, () => console.log("WIRD push prêt"));
